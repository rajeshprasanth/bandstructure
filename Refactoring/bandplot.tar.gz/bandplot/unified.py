#!/usr/bin/env python
import matplotlib.pyplot as plt
import os

X, Y = [], []


#------------------------------------------------------------------------------------------
#Scan for fermi energy(use scf output file)
#------------------------------------------------------------------------------------------
for line in open('Mg3Sb2.0.scf.out', 'r'):
	if "Fermi" in line:
		fermi = float(line.split()[4])
#------------------------------------------------------------------------------------------
#Scan for High symmetry points(use bands output file)
#------------------------------------------------------------------------------------------
numentry=0
for line in open('bands.out', 'r'):
	if "high-symmetry point" in line:
		numentry = numentry + 1
		points = line.split()
		print points


xcoords = [0.0000, 0.5745, 0.9062, 1.5696,1.8853, 2.4598, 2.7915,3.4549,3.7706,4.0864]
plt.xlim(xcoords[0], xcoords[9])
print xcoords


for line in open('bands.xmgr', 'r'):
  values = [float(s) for s in line.split()]
  X.append(values[0])
  Y.append(values[1]-fermi)

for xc in xcoords:
    plt.axvline(x=xc)

plt.xticks([0.0000, 0.5745, 0.9062, 1.5696,1.8853, 2.4598, 2.7915,3.4549,3.7706,4.0864], [r"$\rho$",'M','K','G','A','L','H','A|L','M|K','H'])
plt.axhline(y=0,linestyle='dashed')
plt.plot(X, Y)
plt.show()
